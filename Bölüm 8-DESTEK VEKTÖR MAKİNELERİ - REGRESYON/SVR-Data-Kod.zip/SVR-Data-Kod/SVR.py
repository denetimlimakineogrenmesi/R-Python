#ilgili kutuphanelerin yuklenmesi
import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVR
import math
from math import sqrt

#verinin okunmasi, dataFrame olarak saklanmasi ve gereksiz nitelik alanlarinin atilmasi
dataSvr = pd.read_excel('data_svr.xlsx', sheet_name="Sayfa1", header=None)
dataSvr = pd.DataFrame(dataSvr)
dataSvr = dataSvr.drop(columns=[8,11,17], axis = 1)

#veri setinde hedef nitelik(y) ve öziteliklerin(X) ayristirilmasi
y = list(dataSvr[16])
X = pd.DataFrame((dataSvr.drop(columns=[16])))

#veri setinin egitim ve test amacli olarak bolunmesi
X_egitim, X_test, y_egitim, y_test = train_test_split(X, y, test_size=0.30, random_state=1)

#svr modelinin olusturulmasi
modelSvr = SVR("rbf").fit(X_egitim, y_egitim)

#elde edilen modele gore tahmin degerlerinin elde edilmesi
tahminSvr = modelSvr.predict(X_test)

#model performansi icin RMSE'nin hesaplanmasi
RMSEsvr = np.sqrt(((tahminSvr - y_test) ** 2).mean())

#parametre ayarlamasi icin denenecek parametre degerlerinin belirlenmesi
Svr_par = {"C": np.arange(1,100,10)}

#belirlenen parametre deger araliklarine gore svr modelinin tune edilmesi 
#(en iyi parametrenin GridSearch yontemi ile aranmasi)
tunedSvr = GridSearchCV(modelSvr,Svr_par,cv=5).fit(X_egitim, y_egitim)

#belirlenen en iyi parametre degerlerinin alinarak modelin yeniden eldesi
svrTuned = SVR("rbf", C=pd.Series(tunedSvr.best_params_)[0]).fit(X_egitim, y_egitim)

#elde edilen modele gore yeni tahmin degerlerinin elde edilmesi
tahminSvrTuned = svrTuned.predict(X_test)

#yeni tahmin degerlerine gore model performans degerinin elde edilmesi
RMSEsvrTuned = np.sqrt(((tahminSvrTuned - y_test) ** 2).mean())
