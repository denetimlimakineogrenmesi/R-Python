install.packages("xlsx")
install.packages("clusterSim")
install.packages("caret")
install.packages("e1071")
install.packages("Metrics")
library(xlsx)
library(clusterSim)
library(caret)
library(e1071)
library(Metrics)

#veri okuma
data_svr<-read.xlsx("data_svr.xlsx", sheetName = "Sayfa1", header = FALSE)

#veri okundugunda degiskenler karakter veri tipinde gelirse, asagidaki kod
#satiri ile say�sal degerlere gerekli donusum yapilmalidir.
i<-1:18
data_svr[ , i] <- apply(data_svr[ , i], 2, function(x) as.numeric(as.character(x)))

#sabit degerli degiskenlerin veri setinden cikarilmasi
data_svr<-data_svr[,-c(9,12,18)]

#veri setinin egitim-test olarak ayrilmasi
set.seed(1)
egitimKumesi<-createDataPartition(y=data_svr$X17, p=.70, list = FALSE)
egitim<-data_svr[egitimKumesi,]
test<-data_svr[-egitimKumesi,]
testNitelikleri<-test[,-15]
testHedefNitelik<-test[[15]]
egitimNitelikleri<-egitim[,-15]
egitimHedefNitelik<-egitim[[15]]

#model olusturma
set.seed(1)
modelSvr = svm(egitim$X17~., data=egitim, type="eps-regression")
print(modelSvr)

#tahmin gerceklestirme
tahminSvr = predict(modelSvr, testNitelikleri)

#performans olcusu olarak RMSE degerinin hesaplanmasi
RMSEsvr=rmse(tahminSvr,testHedefNitelik)
print(RMSEsvr)

#modelin parametre ayarlamalari icin tune fonksiyonu kullanimi
tunedSvr=tune(svm, egitimNitelikleri, egitimHedefNitelik, ranges=list(elsilon=seq(0,1,0.1), cost=1:100))

#gerekli ayarlama islemi sonrasi en iyi model ile ayn� model gelistirme, tahmin ve performans
#adimlarinin gerceklestirilmesi
enModelSvr=tunedSvr$best.model
print(enModelSvr)
tahminSvr_tuned=predict(enModelSvr,testNitelikleri)
RMSESvr_tuned=rmse(tahminSvr_tuned,testHedefNitelik)
print(RMSESvr_tuned)

